//
//  LittleLemonReservationApp.swift
//  LittleLemonReservation
//
//  Created by 葉尼爾 on 2023/7/17.
//

import SwiftUI

@main
struct LittleLemonReservationApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
